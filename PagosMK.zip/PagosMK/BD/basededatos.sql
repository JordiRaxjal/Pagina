/*
Navicat MySQL Data Transfer

Source Server         : xammp
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : wisp

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2024-10-24 14:51:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for backups
-- ----------------------------
DROP TABLE IF EXISTS `backups`;
CREATE TABLE `backups` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `archive` varchar(100) NOT NULL,
  `size` varchar(50) NOT NULL,
  `registration_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of backups
-- ----------------------------

-- ----------------------------
-- Table structure for bills
-- ----------------------------
DROP TABLE IF EXISTS `bills`;
CREATE TABLE `bills` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) NOT NULL,
  `clientid` bigint(10) NOT NULL,
  `voucherid` bigint(10) NOT NULL,
  `serieid` bigint(10) NOT NULL,
  `internal_code` varchar(50) NOT NULL,
  `correlative` bigint(5) NOT NULL,
  `date_issue` date NOT NULL,
  `expiration_date` date NOT NULL,
  `billed_month` date NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `discount` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL,
  `remaining_amount` decimal(12,2) NOT NULL,
  `type` bigint(1) NOT NULL,
  `sales_method` bigint(1) NOT NULL,
  `observation` text NOT NULL,
  `state` bigint(1) NOT NULL DEFAULT 2,
  PRIMARY KEY (`id`),
  KEY `serviceid` (`clientid`),
  KEY `userid` (`userid`),
  KEY `voucherid` (`voucherid`),
  KEY `serieid` (`serieid`),
  CONSTRAINT `bills_ibfk_3` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bills_ibfk_5` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bills_ibfk_6` FOREIGN KEY (`voucherid`) REFERENCES `vouchers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bills_ibfk_7` FOREIGN KEY (`serieid`) REFERENCES `voucher_series` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of bills
-- ----------------------------

-- ----------------------------
-- Table structure for business
-- ----------------------------
DROP TABLE IF EXISTS `business`;
CREATE TABLE `business` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `documentid` bigint(10) NOT NULL,
  `ruc` char(11) NOT NULL,
  `business_name` varchar(100) NOT NULL,
  `tradename` varchar(100) NOT NULL,
  `slogan` text NOT NULL,
  `mobile` varchar(9) NOT NULL,
  `mobile_refrence` varchar(9) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `server_host` varchar(200) NOT NULL,
  `port` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `department` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `ubigeo` char(6) NOT NULL,
  `footer_text` text NOT NULL,
  `currencyid` bigint(10) NOT NULL,
  `print_format` varchar(100) NOT NULL,
  `logotyope` varchar(200) NOT NULL,
  `logo_login` varchar(200) NOT NULL,
  `logo_email` varchar(1000) NOT NULL,
  `favicon` varchar(200) NOT NULL,
  `country_code` varchar(20) NOT NULL,
  `google_apikey` text NOT NULL,
  `reniec_apikey` text NOT NULL,
  `background` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`),
  KEY `currencyid` (`currencyid`),
  CONSTRAINT `business_ibfk_1` FOREIGN KEY (`documentid`) REFERENCES `document_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `business_ibfk_2` FOREIGN KEY (`currencyid`) REFERENCES `currency` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of business
-- ----------------------------
INSERT INTO `business` VALUES ('4', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '', '0', '', '', '', '', '', '', '');

-- ----------------------------
-- Table structure for clients
-- ----------------------------
DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) NOT NULL,
  `surnames` varchar(100) NOT NULL,
  `documentid` bigint(10) NOT NULL,
  `document` varchar(15) NOT NULL,
  `mobile` varchar(9) NOT NULL,
  `mobile_optional` varchar(9) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `reference` text NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `latitud` varchar(50) NOT NULL,
  `longitud` varchar(50) NOT NULL,
  `state` bigint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`),
  CONSTRAINT `clients_ibfk_1` FOREIGN KEY (`documentid`) REFERENCES `document_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of clients
-- ----------------------------
INSERT INTO `clients` VALUES ('1', 'PUBLICO', 'GENERAL', '2', '00000000', '000000000', '', '', '', '', null, '', '', '1');

-- ----------------------------
-- Table structure for contracts
-- ----------------------------
DROP TABLE IF EXISTS `contracts`;
CREATE TABLE `contracts` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) NOT NULL,
  `clientid` bigint(10) NOT NULL,
  `internal_code` varchar(50) NOT NULL,
  `payday` bigint(5) NOT NULL,
  `create_invoice` bigint(5) NOT NULL,
  `days_grace` bigint(5) NOT NULL,
  `discount` bigint(1) NOT NULL,
  `discount_price` decimal(12,2) NOT NULL,
  `months_discount` bigint(5) NOT NULL,
  `remaining_discount` bigint(5) NOT NULL,
  `contract_date` datetime NOT NULL,
  `suspension_date` date NOT NULL,
  `finish_date` date NOT NULL,
  `state` bigint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `clientid` (`clientid`),
  CONSTRAINT `contracts_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contracts_ibfk_3` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of contracts
-- ----------------------------

-- ----------------------------
-- Table structure for currency
-- ----------------------------
DROP TABLE IF EXISTS `currency`;
CREATE TABLE `currency` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `currency_iso` varchar(3) NOT NULL,
  `language` varchar(3) NOT NULL,
  `currency_name` varchar(50) NOT NULL,
  `money` varchar(30) NOT NULL,
  `money_plural` varchar(50) NOT NULL,
  `symbol` varchar(3) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of currency
-- ----------------------------
INSERT INTO `currency` VALUES ('1', 'PEN', 'ES', 'NUEVO SOL', 'SOL', 'SOLES', 'S/.', '2022-07-07 19:57:37', '1');

-- ----------------------------
-- Table structure for departures
-- ----------------------------
DROP TABLE IF EXISTS `departures`;
CREATE TABLE `departures` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `billid` bigint(10) NOT NULL,
  `productid` bigint(10) NOT NULL,
  `departure_date` datetime NOT NULL,
  `description` varchar(200) NOT NULL,
  `quantity_departures` bigint(5) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `total_cost` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `billid` (`billid`),
  KEY `productid` (`productid`),
  CONSTRAINT `departures_ibfk_1` FOREIGN KEY (`productid`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of departures
-- ----------------------------

-- ----------------------------
-- Table structure for detail_bills
-- ----------------------------
DROP TABLE IF EXISTS `detail_bills`;
CREATE TABLE `detail_bills` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `billid` bigint(10) NOT NULL,
  `type` bigint(1) NOT NULL,
  `serproid` bigint(5) NOT NULL,
  `description` text NOT NULL,
  `quantity` bigint(5) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `billid` (`billid`),
  CONSTRAINT `detail_bills_ibfk_1` FOREIGN KEY (`billid`) REFERENCES `bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of detail_bills
-- ----------------------------

-- ----------------------------
-- Table structure for detail_contracts
-- ----------------------------
DROP TABLE IF EXISTS `detail_contracts`;
CREATE TABLE `detail_contracts` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `contractid` bigint(10) NOT NULL,
  `serviceid` bigint(10) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `contractid` (`contractid`),
  KEY `serviceid` (`serviceid`),
  CONSTRAINT `detail_contracts_ibfk_1` FOREIGN KEY (`contractid`) REFERENCES `contracts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_contracts_ibfk_2` FOREIGN KEY (`serviceid`) REFERENCES `services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of detail_contracts
-- ----------------------------

-- ----------------------------
-- Table structure for detail_facility
-- ----------------------------
DROP TABLE IF EXISTS `detail_facility`;
CREATE TABLE `detail_facility` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `facilityid` bigint(10) NOT NULL,
  `technicalid` bigint(10) NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `comment` text NOT NULL,
  `state` bigint(1) NOT NULL,
  `red_type` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facilityid` (`facilityid`),
  KEY `technicalid` (`technicalid`),
  CONSTRAINT `detail_facility_ibfk_1` FOREIGN KEY (`facilityid`) REFERENCES `facility` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_facility_ibfk_2` FOREIGN KEY (`technicalid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of detail_facility
-- ----------------------------

-- ----------------------------
-- Table structure for document_type
-- ----------------------------
DROP TABLE IF EXISTS `document_type`;
CREATE TABLE `document_type` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `document` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of document_type
-- ----------------------------
INSERT INTO `document_type` VALUES ('1', 'SIN DOCUMENTO');
INSERT INTO `document_type` VALUES ('2', 'DNI');

-- ----------------------------
-- Table structure for emails
-- ----------------------------
DROP TABLE IF EXISTS `emails`;
CREATE TABLE `emails` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `clientid` bigint(10) NOT NULL,
  `billid` bigint(10) NOT NULL,
  `affair` varchar(500) NOT NULL,
  `sender` varchar(200) NOT NULL,
  `files` varchar(10) NOT NULL,
  `type_file` varchar(100) NOT NULL,
  `template_email` varchar(100) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `billid` (`billid`),
  CONSTRAINT `emails_ibfk_1` FOREIGN KEY (`billid`) REFERENCES `bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `emails_ibfk_2` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of emails
-- ----------------------------

-- ----------------------------
-- Table structure for facility
-- ----------------------------
DROP TABLE IF EXISTS `facility`;
CREATE TABLE `facility` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `clientid` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL,
  `technical` bigint(10) NOT NULL,
  `attention_date` datetime NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `cost` decimal(12,2) NOT NULL,
  `detail` text NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL DEFAULT 2,
  PRIMARY KEY (`id`),
  KEY `technicalid` (`userid`),
  KEY `clientid` (`clientid`),
  CONSTRAINT `facility_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `facility_ibfk_3` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of facility
-- ----------------------------

-- ----------------------------
-- Table structure for forms_payment
-- ----------------------------
DROP TABLE IF EXISTS `forms_payment`;
CREATE TABLE `forms_payment` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(500) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of forms_payment
-- ----------------------------
INSERT INTO `forms_payment` VALUES ('1', 'EFECTIVO', '2022-07-07 21:50:55', '1');

-- ----------------------------
-- Table structure for gallery_images
-- ----------------------------
DROP TABLE IF EXISTS `gallery_images`;
CREATE TABLE `gallery_images` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `clientid` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL,
  `type` bigint(1) NOT NULL,
  `typeid` bigint(10) NOT NULL,
  `registration_date` datetime NOT NULL,
  `image` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `userid` (`userid`),
  CONSTRAINT `gallery_images_ibfk_1` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gallery_images_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of gallery_images
-- ----------------------------
INSERT INTO `gallery_images` VALUES ('1', '2', '1', '1', '1', '2023-11-08 14:19:26', 'jhon_carasco_75a207995b07183564f13c61f0a372f7.png');

-- ----------------------------
-- Table structure for incidents
-- ----------------------------
DROP TABLE IF EXISTS `incidents`;
CREATE TABLE `incidents` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `incident` varchar(500) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of incidents
-- ----------------------------

-- ----------------------------
-- Table structure for income
-- ----------------------------
DROP TABLE IF EXISTS `income`;
CREATE TABLE `income` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `productid` bigint(10) NOT NULL,
  `income_date` datetime NOT NULL,
  `description` varchar(200) NOT NULL,
  `quantity_income` bigint(5) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `total_cost` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `productid` (`productid`),
  CONSTRAINT `income_ibfk_1` FOREIGN KEY (`productid`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of income
-- ----------------------------

-- ----------------------------
-- Table structure for modules
-- ----------------------------
DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `module` varchar(100) NOT NULL,
  `state` bigint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of modules
-- ----------------------------
INSERT INTO `modules` VALUES ('1', 'Dashboard', '1');
INSERT INTO `modules` VALUES ('2', 'Clientes', '1');
INSERT INTO `modules` VALUES ('3', 'Usuarios', '1');
INSERT INTO `modules` VALUES ('4', 'Tickets', '1');
INSERT INTO `modules` VALUES ('5', 'Incidencias', '1');
INSERT INTO `modules` VALUES ('6', 'Facturas', '1');
INSERT INTO `modules` VALUES ('7', 'Productos', '1');
INSERT INTO `modules` VALUES ('8', 'Categorias', '1');
INSERT INTO `modules` VALUES ('9', 'Proveedores', '1');
INSERT INTO `modules` VALUES ('10', 'Pagos', '1');
INSERT INTO `modules` VALUES ('11', 'Servicios', '1');
INSERT INTO `modules` VALUES ('12', 'Empresa', '1');
INSERT INTO `modules` VALUES ('13', 'Instalaciones', '1');
INSERT INTO `modules` VALUES ('14', 'Divisas', '1');
INSERT INTO `modules` VALUES ('15', 'Formas de pago', '1');
INSERT INTO `modules` VALUES ('16', 'Comprobantes', '1');
INSERT INTO `modules` VALUES ('17', 'Unidades', '1');
INSERT INTO `modules` VALUES ('18', 'Correos', '1');

-- ----------------------------
-- Table structure for payments
-- ----------------------------
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `billid` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL,
  `clientid` bigint(10) NOT NULL,
  `internal_code` varchar(50) NOT NULL,
  `paytypeid` bigint(10) NOT NULL,
  `payment_date` datetime NOT NULL,
  `comment` text NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL,
  `amount_total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `remaining_credit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `state` bigint(1) NOT NULL DEFAULT 1,
  `ticket_number` varchar(255) DEFAULT NULL,
  `reference_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `billid` (`billid`),
  KEY `clientid` (`clientid`),
  KEY `userid` (`userid`),
  KEY `paytypeid` (`paytypeid`),
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`billid`) REFERENCES `bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payments_ibfk_4` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payments_ibfk_5` FOREIGN KEY (`paytypeid`) REFERENCES `forms_payment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of payments
-- ----------------------------

-- ----------------------------
-- Table structure for permits
-- ----------------------------
DROP TABLE IF EXISTS `permits`;
CREATE TABLE `permits` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `profileid` bigint(10) NOT NULL,
  `moduleid` bigint(10) NOT NULL,
  `r` bigint(1) NOT NULL,
  `a` bigint(1) NOT NULL,
  `e` bigint(1) NOT NULL,
  `v` bigint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `profileid` (`profileid`),
  KEY `moduleid` (`moduleid`),
  CONSTRAINT `permits_ibfk_1` FOREIGN KEY (`profileid`) REFERENCES `profiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `permits_ibfk_2` FOREIGN KEY (`moduleid`) REFERENCES `modules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of permits
-- ----------------------------
INSERT INTO `permits` VALUES ('1', '1', '1', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('2', '1', '2', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('3', '1', '3', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('4', '1', '4', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('5', '1', '5', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('6', '1', '6', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('7', '1', '7', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('8', '1', '8', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('9', '1', '9', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('10', '1', '10', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('11', '1', '11', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('12', '1', '12', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('13', '1', '13', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('14', '1', '14', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('15', '1', '15', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('16', '1', '16', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('17', '1', '17', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('18', '1', '18', '1', '1', '1', '1');
INSERT INTO `permits` VALUES ('19', '2', '1', '0', '0', '0', '1');
INSERT INTO `permits` VALUES ('20', '2', '2', '1', '0', '0', '1');
INSERT INTO `permits` VALUES ('21', '2', '3', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('22', '2', '4', '1', '1', '0', '1');
INSERT INTO `permits` VALUES ('23', '2', '5', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('24', '2', '6', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('25', '2', '7', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('26', '2', '8', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('27', '2', '9', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('28', '2', '10', '1', '0', '0', '1');
INSERT INTO `permits` VALUES ('29', '2', '11', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('30', '2', '12', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('31', '2', '13', '1', '1', '0', '1');
INSERT INTO `permits` VALUES ('32', '2', '14', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('33', '2', '15', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('34', '2', '16', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('35', '2', '17', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('36', '2', '18', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('91', '3', '1', '0', '0', '1', '1');
INSERT INTO `permits` VALUES ('92', '3', '2', '0', '0', '0', '1');
INSERT INTO `permits` VALUES ('93', '3', '3', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('94', '3', '4', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('95', '3', '5', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('96', '3', '6', '1', '0', '0', '1');
INSERT INTO `permits` VALUES ('97', '3', '7', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('98', '3', '8', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('99', '3', '9', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('100', '3', '10', '1', '0', '0', '1');
INSERT INTO `permits` VALUES ('101', '3', '11', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('102', '3', '12', '0', '0', '0', '1');
INSERT INTO `permits` VALUES ('103', '3', '13', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('104', '3', '14', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('105', '3', '15', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('106', '3', '16', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('107', '3', '17', '0', '0', '0', '0');
INSERT INTO `permits` VALUES ('108', '3', '18', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `internal_code` varchar(20) NOT NULL,
  `barcode` varchar(13) NOT NULL,
  `product` varchar(200) NOT NULL,
  `model` varchar(500) NOT NULL,
  `brand` varchar(500) NOT NULL,
  `extra_info` bigint(1) NOT NULL,
  `serial_number` varchar(50) NOT NULL,
  `mac` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `sale_price` decimal(12,2) NOT NULL,
  `purchase_price` decimal(12,2) NOT NULL,
  `stock` bigint(5) NOT NULL,
  `stock_alert` bigint(5) NOT NULL,
  `categoryid` bigint(10) NOT NULL,
  `unitid` bigint(10) NOT NULL,
  `providerid` bigint(10) NOT NULL,
  `image` text NOT NULL,
  `registration_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `categoryid` (`categoryid`),
  KEY `unitid` (`unitid`),
  KEY `providerid` (`providerid`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`unitid`) REFERENCES `unit` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`categoryid`) REFERENCES `product_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `products_ibfk_3` FOREIGN KEY (`providerid`) REFERENCES `providers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of products
-- ----------------------------

-- ----------------------------
-- Table structure for product_category
-- ----------------------------
DROP TABLE IF EXISTS `product_category`;
CREATE TABLE `product_category` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of product_category
-- ----------------------------

-- ----------------------------
-- Table structure for profiles
-- ----------------------------
DROP TABLE IF EXISTS `profiles`;
CREATE TABLE `profiles` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `profile` varchar(50) NOT NULL,
  `description` varchar(300) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of profiles
-- ----------------------------
INSERT INTO `profiles` VALUES ('1', 'ADMINISTRADOR', 'ACCESOS A TODOS LOS MODULOS', '2022-07-07 15:51:53', '1');
INSERT INTO `profiles` VALUES ('2', 'TECNICO', 'CLIENTES, TICKET Y COBRANZA, CON RESTRICCIONES', '2022-07-07 15:51:53', '1');
INSERT INTO `profiles` VALUES ('3', 'COBRANZA', 'COBRANZA DE FACTURAS PENDIENTES', '2022-07-07 15:51:53', '1');

-- ----------------------------
-- Table structure for providers
-- ----------------------------
DROP TABLE IF EXISTS `providers`;
CREATE TABLE `providers` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `provider` varchar(200) NOT NULL,
  `documentid` bigint(10) NOT NULL,
  `document` varchar(15) NOT NULL,
  `mobile` varchar(9) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of providers
-- ----------------------------

-- ----------------------------
-- Table structure for services
-- ----------------------------
DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `internal_code` varchar(20) NOT NULL,
  `service` varchar(200) NOT NULL,
  `type` bigint(1) NOT NULL,
  `rise` bigint(5) NOT NULL,
  `rise_type` varchar(50) NOT NULL,
  `descent` bigint(5) NOT NULL,
  `descent_type` varchar(50) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `details` text NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of services
-- ----------------------------

-- ----------------------------
-- Table structure for tickets
-- ----------------------------
DROP TABLE IF EXISTS `tickets`;
CREATE TABLE `tickets` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) NOT NULL,
  `clientid` bigint(10) NOT NULL,
  `technical` bigint(10) NOT NULL,
  `incidentsid` bigint(10) NOT NULL,
  `description` text NOT NULL,
  `priority` bigint(1) NOT NULL,
  `attention_date` datetime NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL DEFAULT 2,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `clientid` (`clientid`),
  KEY `incidentsid` (`incidentsid`),
  CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`incidentsid`) REFERENCES `incidents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tickets_ibfk_3` FOREIGN KEY (`clientid`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tickets_ibfk_4` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of tickets
-- ----------------------------

-- ----------------------------
-- Table structure for ticket_solution
-- ----------------------------
DROP TABLE IF EXISTS `ticket_solution`;
CREATE TABLE `ticket_solution` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `ticketid` bigint(10) NOT NULL,
  `technicalid` bigint(10) NOT NULL,
  `opening_date` datetime NOT NULL,
  `closing_date` datetime NOT NULL,
  `comment` text NOT NULL,
  `state` bigint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticketid` (`ticketid`),
  KEY `technicalid` (`technicalid`),
  CONSTRAINT `ticket_solution_ibfk_1` FOREIGN KEY (`ticketid`) REFERENCES `tickets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ticket_solution_ibfk_2` FOREIGN KEY (`technicalid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of ticket_solution
-- ----------------------------

-- ----------------------------
-- Table structure for tools
-- ----------------------------
DROP TABLE IF EXISTS `tools`;
CREATE TABLE `tools` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `facilityid` bigint(10) NOT NULL,
  `productid` bigint(10) NOT NULL,
  `quantity` bigint(10) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `product_condition` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `facilityid` (`facilityid`),
  KEY `productid` (`productid`),
  CONSTRAINT `tools_ibfk_1` FOREIGN KEY (`productid`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tools_ibfk_2` FOREIGN KEY (`facilityid`) REFERENCES `facility` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of tools
-- ----------------------------

-- ----------------------------
-- Table structure for unit
-- ----------------------------
DROP TABLE IF EXISTS `unit`;
CREATE TABLE `unit` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `code` varchar(5) NOT NULL,
  `united` varchar(50) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of unit
-- ----------------------------
INSERT INTO `unit` VALUES ('1', 'NIU', 'UNIDAD', '2022-07-07 21:03:40', '1');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) NOT NULL,
  `surnames` varchar(100) NOT NULL,
  `documentid` bigint(10) NOT NULL,
  `document` varchar(15) NOT NULL,
  `mobile` varchar(9) NOT NULL,
  `email` varchar(200) NOT NULL,
  `profileid` bigint(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `token` varchar(100) NOT NULL,
  `image` varchar(200) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `documentid` (`documentid`),
  KEY `profileid` (`profileid`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`profileid`) REFERENCES `profiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`documentid`) REFERENCES `document_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'JOHN', 'DOE', '2', '00000000', '000000000', 'john.doe@example', '1', 'admin', 'UlprNGhjTjNEeGpqb3oxNUIzY0JZdz09', '', 'user_default.png', '2022-07-07 19:39:22', '1');

-- ----------------------------
-- Table structure for vouchers
-- ----------------------------
DROP TABLE IF EXISTS `vouchers`;
CREATE TABLE `vouchers` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `voucher` varchar(100) NOT NULL,
  `registration_date` datetime NOT NULL,
  `state` bigint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of vouchers
-- ----------------------------
INSERT INTO `vouchers` VALUES ('1', 'RECIBO', '2022-07-07 17:37:14', '1');
INSERT INTO `vouchers` VALUES ('2', 'FACTURA ELECTRONICA', '2022-07-07 18:06:12', '1');
INSERT INTO `vouchers` VALUES ('3', 'BOLETA ELECTRONICA', '2022-07-07 09:27:20', '1');

-- ----------------------------
-- Table structure for voucher_series
-- ----------------------------
DROP TABLE IF EXISTS `voucher_series`;
CREATE TABLE `voucher_series` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `serie` varchar(50) NOT NULL,
  `fromc` bigint(10) NOT NULL,
  `until` bigint(10) NOT NULL,
  `voucherid` bigint(10) NOT NULL,
  `available` bigint(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `voucherid` (`voucherid`),
  CONSTRAINT `voucher_series_ibfk_1` FOREIGN KEY (`voucherid`) REFERENCES `vouchers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- ----------------------------
-- Records of voucher_series
-- ----------------------------
INSERT INTO `voucher_series` VALUES ('1', '2022-07-07', 'R001', '1', '1000000', '1', '999997');
