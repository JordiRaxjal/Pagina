<?php
/* RUTA DEL SISTEMA */
// const BASE_URL = "127.0.0.1";  /* MODIFICAR ESTA LINEA CON LA URL QUE SE VA A USAR*/
const BASE_URL = "http://localhost/wisp/";
/* ZONA HORARIA*/
date_default_timezone_set('America/Lima');
/* CONSTANTE DE CONEXION */
const DB_HOST = "localhost";
const DB_NAME = "wisp"; ///* MODIFICAR ESTA LINEA CON EL NOMBRE DE LA BASE DE DATOS*/
const DB_USER = "root"; ///* MODIFICAR ESTA LINEA CON EL USUARIO DE LA BASE DE DATOS*/
const DB_PASSWORD = ""; ///* MODIFICAR ESTA LINEA CON LA CLAVE DE LA BASE DE DATOS*/
const DB_CHARSET = "utf8";
/* BACKUP */
const TABLES_NAME = "Tables_in_superwisp"; //Tables_in_codigosf_superwisp
/* DESARROLLADOR */
const DEVELOPER = "CodigosFree";
const DEVELOPER_WEBSITE = "https://www.youtube.com/softwareguatemala/videos";
const DEVELOPER_EMAIL = "soyeliu@gmail.com";
const DEVELOPER_MOBILE = "+50245118800";
/* SISTEMA */
const NAME_SYSTEM = "SUPERWISP";
/* CONSTANTES DE ENCRIPTACION */
const METHOD = "AES-256-CBC";
const SECRET_KEY = 'CYDTEC-PUCALLPA';
const SECRET_IV = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';
/* CONSTANTES DE MODULOS */
const DASHBOARD = 1;
const CLIENTS = 2;
const USERS = 3;
const TICKETS = 4;
const INCIDENTS = 5;
const BILLS = 6;
const PRODUCTS = 7;
const CATEGORIES = 8;
const SUPPLIERS = 9;
const PAYMENTS = 10;
const SERVICES = 11;
const BUSINESS = 12;
const INSTALLATIONS = 13;
const CURRENCYS = 14;
const RUNWAY = 15;
const VOUCHERS = 16;
const UNITS = 17;
const EMAIL = 18;
/* DELIMITADORES */
const SPD = ".";
const SPM = ",";
/* USUARIOS */
const ADMINISTRATOR = 1;
const TECHNICAL = 2;
const CHARGES = 3;
